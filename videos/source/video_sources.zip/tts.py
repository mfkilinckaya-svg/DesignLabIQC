import subprocess, json, sys, wave
from scenes import V1, V2
import os
os.makedirs('audio', exist_ok=True)
durs={}
for vid,scenes in (('v1',V1),('v2',V2)):
    for sid,cap,nar in scenes:
        out=f'audio/{vid}_{sid}.wav'
        subprocess.run(['piper','-m','/tmp/en-us-ryan-high.onnx','--length-scale','1.08','--sentence-silence','0.45','-f',out],input=nar.encode(),check=True,capture_output=True)
        with wave.open(out) as w: d=w.getnframes()/w.getframerate()
        durs[f'{vid}_{sid}']=d
json.dump(durs,open('audio/durations.json','w'),indent=1)
for k,v in durs.items(): print(k, round(v,1))
print('v1 total', round(sum(v for k,v in durs.items() if k.startswith('v1')),1), 'v2 total', round(sum(v for k,v in durs.items() if k.startswith('v2')),1))
