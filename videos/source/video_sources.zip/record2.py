from playwright.sync_api import sync_playwright
import json,subprocess,time,os
from scenes import V2
srv=subprocess.Popen(['python3','-m','http.server','8765'],cwd='/home/claude/work/repo/tool',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
durs=json.load(open('audio/durations.json'))
CSS=""".max-w-7xl{max-width:1560px !important} body{zoom:1.2}
#capbar{position:fixed;left:0;right:0;bottom:0;height:78px;background:#0f172a;color:#f8fafc;display:flex;align-items:center;padding:0 48px;font-size:24px;font-style:italic;z-index:9998;opacity:0;transition:opacity .5s;zoom:1}
#capbar.show{opacity:1}
#cur{position:fixed;z-index:9999;width:22px;height:30px;pointer-events:none;zoom:1;left:0;top:0;transition:transform .05s}
#hl{position:absolute;border:3px solid #0f766e;border-radius:4px;pointer-events:none;z-index:9997;display:none;box-shadow:0 0 0 4px rgba(15,118,110,.15)}
#overlay2{position:fixed;inset:0;background:#fff;z-index:10000;display:none;flex-direction:column;align-items:center;justify-content:center;text-align:center;zoom:1}
#overlay2 h1{font-size:50px;color:#0f172a;margin:0 0 20px 0}#overlay2 p{font-size:26px;color:#475569;margin:0;max-width:1200px;line-height:1.4}#overlay2 .s{margin-top:50px;font-size:20px;color:#94a3b8}
#csvprev{position:fixed;right:40px;bottom:100px;width:1180px;max-height:560px;overflow:hidden;background:#fff;border:1px solid #cbd5e1;box-shadow:0 10px 40px rgba(0,0,0,.25);z-index:9996;padding:16px 20px;font:13px/1.5 monospace;white-space:pre;display:none;zoom:1}
"""
JS="""
const cap=document.createElement('div');cap.id='capbar';document.body.appendChild(cap);
const cur=document.createElement('div');cur.id='cur';cur.innerHTML='<svg width="22" height="30" viewBox="0 0 22 30"><path d="M2 2 L2 24 L8 18 L12 28 L16 26 L12 17 L20 17 Z" fill="#111" stroke="#fff" stroke-width="1.5"/></svg>';document.body.appendChild(cur);
const hl=document.createElement('div');hl.id='hl';document.body.appendChild(hl);
const ov=document.createElement('div');ov.id='overlay2';document.body.appendChild(ov);
const cp=document.createElement('div');cp.id='csvprev';document.body.appendChild(cp);
window.addEventListener('mousemove',e=>{cur.style.transform=`translate(${e.clientX}px,${e.clientY}px)`;});
window.setCap=t=>{if(!t){cap.classList.remove('show');return;}cap.textContent=t;cap.classList.add('show');};
window.setHl=r=>{if(!r){hl.style.display='none';return;}hl.style.display='block';hl.style.left=(r.x-6+window.scrollX)+'px';hl.style.top=(r.y-4+window.scrollY)+'px';hl.style.width=(r.w+12)+'px';hl.style.height=(r.h+8)+'px';};
window.showOv=(h,p,s)=>{ov.innerHTML=`<h1>${h}</h1><p>${p||''}</p><div class=s>${s||''}</div>`;ov.style.display='flex';};window.hideOv=()=>{ov.style.display='none'};
window.showCsv=t=>{cp.textContent=t;cp.style.display='block'};window.hideCsv=()=>{cp.style.display='none'};
"""
Z=1.0
timeline=[]
def main():
    with sync_playwright() as p:
        b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1920,'height':1080},record_video_dir='vid2',record_video_size={'width':1920,'height':1080},accept_downloads=True)
        pg=ctx.new_page(); pg.goto('http://localhost:8765/iqc-rule-designer.html'); pg.wait_for_timeout(1500)
        pg.evaluate("localStorage.clear()"); pg.reload(); pg.wait_for_timeout(2000)
        pg.add_style_tag(content=CSS); pg.evaluate(JS); pg.mouse.move(900,400)
        pg.evaluate("showOv('Using the rule-design tool','Supplementary Video 2 · iqc-rule-designer, a single-file browser tool for deriving control rules from measured imprecision','Helse Møre og Romsdal · Sysmex XR-Series · 2026')")
        T0=time.time(); 
        def now(): return time.time()-T0
        def sleep_until(t): 
            d=t-now()
            if d>0: pg.wait_for_timeout(int(d*1000))
        def box(loc):
            bb=loc.bounding_box(); return {'x':bb['x']*Z,'y':bb['y']*Z,'w':bb['width']*Z,'h':bb['height']*Z}
        def move_to(loc,dx=0.5,dy=0.5,steps=30):
            bb=box(loc); pg.mouse.move(bb['x']+bb['w']*dx,bb['y']+bb['h']*dy,steps=steps)
        def click(loc):
            move_to(loc); pg.wait_for_timeout(250); pg.mouse.down(); pg.wait_for_timeout(80); pg.mouse.up()
        def hl(loc): 
            bb=loc.bounding_box(); pg.evaluate("setHl("+json.dumps({'x':bb['x']*Z,'y':bb['y']*Z,'w':bb['width']*Z,'h':bb['height']*Z})+")")
        def unhl(): pg.evaluate("setHl(null)")
        def scroll_to(loc,offset=120):
            y=loc.bounding_box()['y']*Z+pg.evaluate("window.scrollY")-offset
            pg.evaluate(f"window.scrollTo({{top:{y},behavior:'smooth'}})"); pg.wait_for_timeout(900)
        def typeinto(loc,val):
            click(loc); pg.keyboard.press('Control+A'); pg.wait_for_timeout(150); pg.keyboard.type(val,delay=140); pg.keyboard.press('Tab'); pg.wait_for_timeout(300)
        def start(i):
            sid,capt,_=V2[i]; st=now(); pg.evaluate("setCap("+json.dumps(capt)+")"); timeline.append((sid,st+0.3,durs['v2_'+sid])); return st
        def sec(): return pg.locator('section',has=pg.locator('input[value="MCHC"]')).first
        pg.wait_for_timeout(4500); pg.evaluate("hideOv()")
        # ---- Scene 1
        st=start(0); D=durs['v2_s1']
        pg.wait_for_timeout(2500); pg.mouse.move(700,300,steps=20)
        sleep_until(st+9); scroll_to(sec(),60)
        sleep_until(st+13); s=sec(); badges=s.locator('header span.rounded, header .rounded').filter(has_text='σ')
        b1=s.locator('header').get_by_text('σ ').first; move_to(b1); hl(b1); sleep_until(st+16.5)
        b2=s.locator('header').get_by_text('False alarms').first; move_to(b2); hl(b2); sleep_until(st+20.5)
        b3=s.locator('header').get_by_text('Detection').first; move_to(b3); hl(b3); sleep_until(st+25); unhl()
        sleep_until(st+D+1.5)
        # ---- Scene 2
        st=start(1); D=durs['v2_s2']; s=sec(); ths=s.locator('thead th')
        scroll_to(s.locator('table').first,330); 
        seq=[(1,3.5),(2,5),(3,6.5),(4,8),(5,9.5),(6,13),(7,15),(8,17),(11,19),(12,21.5),(14,23.5),(9,26),(10,28.5)]
        for idx,tt in seq:
            th=ths.nth(idx); move_to(th,steps=15); hl(th); sleep_until(st+tt)
        unhl(); sleep_until(st+D+1.5)
        # ---- Scene 3
        st=start(2); D=durs['v2_s3']; s=sec(); chips=s.locator('button[title^="Set allowable total error"]')
        scroll_to(s,60); strip=s.locator('p:has-text("Same measurement")').first; sleep_until(st+4); move_to(chips.nth(0)); hl(strip); sleep_until(st+9); unhl()
        click(chips.filter(has_text='BV EFLM (optimal)')); sleep_until(st+12)
        hd=s.locator('header').get_by_text('σ ').first; move_to(hd); hl(hd); sleep_until(st+15)
        cs=s.locator('thead th',has_text='Critical shift'); move_to(cs); hl(cs); sleep_until(st+18)
        dt=s.locator('thead th',has_text='Detection').first; move_to(dt); hl(dt); sleep_until(st+22.5); unhl()
        click(chips.filter(has_text='Noklus')); sleep_until(st+25); move_to(hd); hl(hd); sleep_until(st+30); unhl()
        sleep_until(st+D+1.5)
        # ---- Scene 4
        st=start(3); D=durs['v2_s4']; s=sec()
        kin=s.locator('tbody tr').nth(0).locator('input').nth(5); sleep_until(st+2.5); typeinto(kin,'2')
        fa=s.locator('header').get_by_text('False alarms').first; move_to(fa); hl(fa); sleep_until(st+11); unhl()
        btn=s.get_by_role('button',name='Search for rules'); scroll_to(btn,700); sleep_until(st+13); click(btn); pg.wait_for_timeout(400)
        sug=s.locator('.bg-teal-50').first; hl(sug); sleep_until(st+24); unhl(); click(s.get_by_role('button',name='Apply')); sleep_until(st+27)
        scroll_to(s,60); rowk=s.locator('tbody tr').nth(0).locator('input').nth(5); move_to(rowk); hl(s.locator('tbody').first); sleep_until(st+32); unhl()
        meter=s.locator('.mb-4').first; move_to(meter); hl(meter); sleep_until(st+37); unhl()
        sleep_until(st+D+1.5)
        # ---- Scene 5
        st=start(4); D=durs['v2_s5']
        pg.evaluate("window.scrollTo({top:0,behavior:'smooth'})"); pg.wait_for_timeout(900)
        ib=pg.get_by_role('button',name='Import results'); sleep_until(st+3); move_to(ib); sleep_until(st+7.5)
        with pg.expect_file_chooser() as fc:
            click(ib)
        fc.value.set_files('/home/claude/work/repo/docs/import_demo.csv'); pg.wait_for_timeout(1500)
        stat=pg.locator('.font-mono.text-xs.text-slate-500').first; hl(stat); sleep_until(st+12); unhl()
        s=sec(); scroll_to(s,60); sleep_until(st+15)
        cvc=s.locator('tbody tr').nth(0).locator('input').nth(2); move_to(cvc); hl(cvc); sleep_until(st+20)
        tg=s.locator('tbody tr').nth(0).locator('input').nth(1); move_to(tg); hl(tg); sleep_until(st+24)
        bi=s.locator('tbody tr').nth(0).locator('input').nth(3); move_to(bi); hl(bi); sleep_until(st+30)
        off=s.locator('thead th',has_text='Offset (SD)'); move_to(off); hl(off); sleep_until(st+36)
        fo=s.locator('thead th',has_text='False alarm, offset'); move_to(fo); hl(fo); sleep_until(st+41)
        wo=s.locator('header').get_by_text('With offset').first; move_to(wo); hl(wo); sleep_until(st+D+1.5); unhl()
        # ---- Scene 6
        st=start(5); D=durs['v2_s6']; s=sec()
        tg=s.locator('tbody tr').nth(0).locator('input').nth(1); move_to(tg); hl(tg); sleep_until(st+8); unhl()
        bi=s.locator('tbody tr').nth(0).locator('input').nth(3); sleep_until(st+13); typeinto(bi,'2.61')
        off=s.locator('thead th',has_text='Offset (SD)'); move_to(off); hl(off); sleep_until(st+19)
        fa=s.locator('thead th',has_text='False alarm').first; move_to(fa); hl(fa); sleep_until(st+22)
        fo=s.locator('thead th',has_text='False alarm, offset'); move_to(fo); hl(fo); sleep_until(st+26); unhl()
        wo=s.locator('header').get_by_text('With offset').first; move_to(wo); hl(wo); sleep_until(st+33); unhl()
        typeinto(bi,'1.14'); sleep_until(st+D+1.5)
        # ---- Scene 7
        st=start(6); D=durs['v2_s7']
        pg.evaluate("window.scrollTo({top:0,behavior:'smooth'})"); pg.wait_for_timeout(900)
        eb=pg.get_by_role('button',name='Export CSV'); move_to(eb)
        with pg.expect_download() as dl:
            click(eb)
        d=dl.value; d.save_as('/home/claude/work/build/vid2/iqc-control-rules.csv')
        lines=open('/home/claude/work/build/vid2/iqc-control-rules.csv').read().splitlines()
        cols=[0,1,2,3,4,5,6,7,8,9,11,13,14,15,16,19]
        import csv,io
        rows=list(csv.reader(io.StringIO("\n".join(lines))))
        prev="iqc-control-rules.csv\n\n"+"\n".join("  ".join((r[c] if c<len(r) else '')[:14].ljust(14) for c in cols) for r in rows[:1]+[r for r in rows if r[0] in('Hematology','') ][:0]+rows[1:])
        mrows=[r for r in rows[1:]]; # show MCHC rows
        i=[k for k,r in enumerate(rows) if r[1]=='MCHC'][0]
        prev="iqc-control-rules.csv  (export, opened as a table)\n\n"+"\n".join("  ".join((r[c] if c<len(r) else '')[:13].ljust(13) for c in cols) for r in [rows[0]]+rows[i:i+3])
        pg.evaluate("showCsv("+json.dumps(prev)+")"); sleep_until(st+11); pg.evaluate("hideCsv()")
        mt=pg.get_by_role('button',name='Method and references'); click(mt); pg.wait_for_timeout(700)
        pg.evaluate("window.scrollTo({top:900,behavior:'smooth'})"); sleep_until(st+D+1.5)
        pg.evaluate("setCap('')"); pg.evaluate("showOv('iqc-rule-designer','Single-file HTML · MIT licence · deposited with the spreadsheet, data and analysis code','Repository DOI: to be added')")
        pg.wait_for_timeout(6000)
        end=now(); ctx.close(); b.close()
    json.dump({'timeline':timeline,'end':end},open('vid2/timeline.json','w')); print(timeline,end)
try: main()
finally: srv.terminate()
