# Video sources — how the two supplementary videos were produced

Everything is generated; nothing was recorded by hand.

- `scenes.py`      caption card + narration text per scene (V1 = concept video, V2 = tool walkthrough)
- `tts.py`         narration synthesis with Piper (voice en-us-ryan-high, length-scale 1.08) -> audio/*.wav + durations.json
- `video1.html`    the concept video: 1920x1080 HTML/SVG animation driven by startScene(id, duration, caption).
                   Data (data.json) = MCHC L1 control results, per-analyser pooled within-lot CV, LIS/observed SD ratios.
                   fig3.png = manuscript Figure 3.
- `record1.py`     plays video1.html scene by scene in headless Chromium (Playwright) and records a .webm
- `record2.py`     drives tool/iqc-rule-designer.html (served locally) through the walkthrough, with an injected
                   cursor, highlight box and caption bar, and records a .webm
- `offset.py`, `offset2.py`  find the frame where the opening / closing card first appears (recording clock drifts
                   ~1-3 % against wall clock); the two anchors give the linear correction used by mux.py
- `mux.py vidN <webm> <out.mp4> <A> <B>`  places each scene's narration at B*t_scene, cuts the video at A,
                   encodes H.264/AAC and writes narration.srt

Re-rendering only the closing card (e.g. to insert the repository DOI): edit the showOverlay()/showOv() call at the end
of record1.py / record2.py, re-run the record script, offset scripts and mux.py.

Requirements: python3, playwright (chromium), piper-tts + voice model, ffmpeg, numpy, PIL.
