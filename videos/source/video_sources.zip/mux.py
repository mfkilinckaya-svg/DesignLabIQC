import json,sys,numpy as np,wave,subprocess,textwrap
from scenes import V1,V2
vid=sys.argv[1]; webm=sys.argv[2]; out=sys.argv[3]; A=float(sys.argv[4]); B=float(sys.argv[5])
tl=json.load(open(f'{vid}/timeline.json')); scenes=V1 if vid=='vid1' else V2
SR=22050
total=int((tl['end']*B+1)*SR); mix=np.zeros(total,dtype=np.float32)
srt=[];n=1
def ts(s): h=int(s//3600);m=int(s%3600//60);sec=s%60;return f"{h:02d}:{m:02d}:{int(sec):02d},{int((sec%1)*1000):03d}"
for sid,st,d in tl['timeline']:
    st=st*B
    w=wave.open(f'audio/{ "v1" if vid=="vid1" else "v2"}_{sid}.wav'); assert w.getframerate()==SR
    a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
    i=int(st*SR); mix[i:i+len(a)]+=a*0.9
    nar=[x for x in scenes if x[0]==sid][0][2]
    # split narration into sentences for srt, distribute time by length
    sents=[s.strip() for s in nar.replace('; ','. ').split('. ') if s.strip()]
    L=sum(len(s) for s in sents); t=st
    for s in sents:
        dd=d*len(s)/L; srt.append(f"{n}\n{ts(t)} --> {ts(t+dd-0.05)}\n{s.rstrip('.')}.\n"); n+=1; t+=dd
open(f'{vid}/narration.srt','w').write("\n".join(srt))
mix=np.clip(mix,-1,1); wo=wave.open(f'{vid}/track.wav','w'); wo.setnchannels(1); wo.setsampwidth(2); wo.setframerate(SR); wo.writeframes((mix*32767).astype(np.int16).tobytes()); wo.close()
subprocess.run(['ffmpeg','-y','-loglevel','error','-ss',str(A),'-i',webm,'-i',f'{vid}/track.wav','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-r','25','-c:a','aac','-b:a','128k','-ar','44100','-shortest','-movflags','+faststart',out],check=True)
print('ok')
