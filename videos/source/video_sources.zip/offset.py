import subprocess,numpy as np,sys
webm=sys.argv[1]; W,H=192,108
raw=subprocess.run(['ffmpeg','-loglevel','error','-t','9','-i',webm,'-vf',f'fps=25,scale={W}:{H}','-f','rawvideo','-pix_fmt','gray','-'],capture_output=True).stdout
fr=np.frombuffer(raw,dtype=np.uint8).reshape(-1,H,W).astype(float)
ref=fr[int(6*25)]
d=[np.abs(f-ref).mean() for f in fr]
first=next(i for i,v in enumerate(d) if v<1.0)
print('overlay first frame at',first/25,'s'); print([round(x,1) for x in d[:first+3]][-10:])
