from playwright.sync_api import sync_playwright
import json,subprocess,time,os
srv=subprocess.Popen(['python3','-m','http.server','8766'],cwd='/home/claude/work/build',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
from scenes import V1
durs=json.load(open('audio/durations.json'))
PAD=2.2
timeline=[]
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1920,'height':1080},record_video_dir='vid1',record_video_size={'width':1920,'height':1080})
    pg=ctx.new_page(); pg.goto('http://localhost:8766/video1.html'); pg.wait_for_timeout(300)
    pg.evaluate("init("+open('data.json').read()+")")
    pg.evaluate("showOverlay('How a control rule should be built','Supplementary Video 1 · Haematology internal quality control rules derived from laboratory imprecision','Helse Møre og Romsdal · Sysmex XR-Series · 2026')")
    T0=time.time(); pg.wait_for_timeout(4500)
    for i,(sid,cap,nar) in enumerate(V1):
        D=durs['v1_'+sid]+PAD
        st=time.time()-T0
        pg.evaluate(f"startScene('{sid}',{D},{json.dumps(cap)},'Supplementary Video 1 — How a control rule should be built','Scene {i+1} of 9')")
        timeline.append((sid,st+0.6,durs['v1_'+sid]))
        pg.wait_for_timeout(int(D*1000))
    pg.evaluate("showOverlay('Kontrolregler v1.1 · iqc-rule-designer','Spreadsheet, browser tool, data and analysis code are deposited with the manuscript.','Repository DOI: to be added')")
    pg.wait_for_timeout(6000)
    end=time.time()-T0
    ctx.close(); b.close()
json.dump({'timeline':timeline,'end':end},open('vid1/timeline.json','w'))
print(timeline,end)
srv.terminate()
