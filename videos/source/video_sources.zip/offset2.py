import subprocess,numpy as np,sys
webm=sys.argv[1]; W,H=192,108
dur=float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',webm],capture_output=True,text=True).stdout)
ss=dur-14
raw=subprocess.run(['ffmpeg','-loglevel','error','-ss',str(ss),'-i',webm,'-vf',f'fps=25,scale={W}:{H}','-f','rawvideo','-pix_fmt','gray','-'],capture_output=True).stdout
fr=np.frombuffer(raw,dtype=np.uint8).reshape(-1,H,W).astype(float)
ref=fr[-5]
d=[np.abs(f-ref).mean() for f in fr]
first=next(i for i,v in enumerate(d) if v<1.0)
print('dur',dur,'closing overlay first frame at',ss+first/25)
